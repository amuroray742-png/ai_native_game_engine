from pathlib import Path
import sys,json,shutil
sys.path.insert(0,'scripts')
from verify_unity_ui import *
base=Path('TestResults/ui-shutdown-editor-r3-20261116').resolve()
out=base/'recovery';out.mkdir()
s=json.loads((base/'progress.json').read_text());p=Path(s['project'])
assert [r['name'] for r in s['tests']]==['on-ui-edit','on-ui-play']
assert fingerprint(ROOT,PROJECT)==json.loads((base/'sources.json').read_text())
shutil.copy2(__file__,out/'runner.py')
def suite(label,mode,filt,minimum,allow=()):
 xml=out/(label+'.xml');log=out/(label+'.log')
 run_command(out,label,['unity','test',p,'--mode',mode,'--filter',filt,'--output',xml,'--timeout','800','--format','json','--','-logFile',log])
 check_log(log,allow);read_unity_version(log,s['unity'])
 return read_test_report(xml,filt,minimum)
s['tests'].append(suite('on-demo','PlayMode',DEMO_FILTER,15,EXPECTED_EXCEPTIONS['demo']))
log=out/'reload-off.log'
run_command(out,'reload-off',['unity','run',p,'--timeout','800','--log-file',log,'--no-tail','--format','json','--','-executeMethod','AiNative.UIDemo.Editor.UIDemoBuilder.ReloadOff'])
check_log(log)
for name,mode,filt,minimum in [('ui-edit','EditMode',UI_FILTER,25),('ui-play','PlayMode',UI_FILTER,109),('demo','PlayMode',DEMO_FILTER,15)]:
 s['tests'].append(suite('off-'+name,mode,filt,minimum,EXPECTED_EXCEPTIONS.get(name,())))
for i in range(3):assert s['tests'][i]['tests']==s['tests'][i+3]['tests']
s.update(status='Passed',totalExecutions=sum(r['total'] for r in s['tests']),recovery='on-demo CLI TEST_RUN_ERROR exit 6 without report retained at parent; retried only incomplete suite and continued remaining matrix')
write_json(base/'completed-summary.json',s)
reports=[]
for mode in ('EditMode','PlayMode'): reports.append(suite('assets-'+mode.lower(),mode,'AiNative.UnityCore.Assets',1))
assert fingerprint(ROOT,PROJECT)==json.loads((base/'sources.json').read_text())
write_json(base/'assets-summary.json',dict(status='Passed',tests=reports,totalExecutions=sum(r['total'] for r in reports),scope='Full Assets EditMode and PlayMode in isolated UIDemo; Domain Reload off'))
print('UI and Assets final suites passed',flush=True)
