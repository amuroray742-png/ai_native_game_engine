from pathlib import Path
import sys,json
sys.path.insert(0,'scripts')
from verify_unity_ui import *
out=Path('TestResults/ui-shutdown-editor-r3-20261116').resolve()
s=verify(out)
p=Path(s['project']);reports=[]
for mode in ('EditMode','PlayMode'):
 label='assets-'+mode.lower();xml=out/(label+'.xml');log=out/(label+'.log')
 run_command(out,label,['unity','test',p,'--mode',mode,'--filter','AiNative.UnityCore.Assets','--output',xml,'--timeout','800','--format','json','--','-logFile',log])
 check_log(log);read_unity_version(log,s['unity'])
 reports.append(read_test_report(xml,'AiNative.UnityCore.Assets'))
assert fingerprint(ROOT,PROJECT)==json.loads((out/'sources.json').read_text())
write_json(out/'assets-summary.json',dict(status='Passed',tests=reports,totalExecutions=sum(r['total'] for r in reports),scope='Assets package full EditMode and PlayMode in UIDemo isolated project after UI dual Domain Reload matrix'))
print('Assets suites passed',flush=True)
