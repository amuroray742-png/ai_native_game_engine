# Native input verification — 2026-11-13

Target: isolated UIDemo, Unity 6000.3.23f1, Windows, legacy StandaloneInputModule. Pipeline 1.0.0 was installed only in the isolated verification project. Command discovery found runtime simulate_key/simulate_pointer for the new Input System; these were not used to claim legacy input verification.

Windows Computer Use (@oai/sky SendInput) targeted the unique returned UIDemo window. Two window screenshot attempts timed out; no stale screenshot coordinates were reused. Text accessibility continued to identify the focused UnityEditor.GameView. Visual evidence came from Pipeline capture game_view with source=screen, never a camera capture.

The maximized Game View rendered at 2560 x 1256. A native click at window (1280,720) in the observed blank page area gave Unity Input.mousePosition (1280,660). This established the window-to-Game-View mapping. Runtime RectTransformUtility.WorldToScreenPoint located the real buttons, with y_window = 1380 - y_game. Native clicks and keys below were injected through sky, not ExecuteEvents or button.onClick.Invoke.

1. Home Next at native (199,572): pages 1 -> 2, selection Third; native-mouse-next.json records Unity mouse (198,808), frame 23095.
2. Return: pages 2 -> 3, selection Transparent; native-keyboard-third.json.
3. Click Modal at (535,572): modal count 1, selection SecondModal; native-modal-first.json.
4. Return: modal count 2, selection Back; native-modal-second.json and modals-final.png.
5. Return: modal count 1, selection SecondModal. Right moved selection to Back; Return restored modal count 0 and prior Details selection Modal; native-back-one/zero.json.
6. Click host Clear at (224,305): session 1 -> 2, page depth 1; native-clear.json.
7. Click host Scene at (1345,305): active scene Other, session 2, depth 1, Core running; native-scene.json.

Visible player-loop progress was independently observed using job wait frameCount changed (visible-ticking.json). Final visible console reported zero errors and no compile failure; retained warnings include Unity's legacy Input Manager deprecation notice. No remote CI, physical human-operated mouse, device, or Player claim is made: these are OS-injected native input events in a visible Editor.

stable-final.png, modals-final.png and transition-final.png are screen captures downsampled to 1280 x 628 without changing aspect ratio. UIDemoCapture paused the actual transition after its entering state and 100 ms: transition-state.json contains Home Visible, Gallery Entering, pending 1. After resume, transition-complete.json records depth 2, pending 0, no host error. The isolated Editor was then stopped and gracefully closed, with auto-tick and background override restored. The final test matrix ran afterwards.

Earlier screenshots home-screen/gallery-screen/gallery-maximized/gallery-wide show the original wide-screen layout issue and are preserved as development evidence; final screenshots supersede them. One exploratory script eval of EditorWindow.focusedWindow returned null; explicit GameView selection resolved it. It did not change production code or count as test evidence.
