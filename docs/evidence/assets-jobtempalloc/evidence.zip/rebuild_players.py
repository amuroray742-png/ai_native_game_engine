import json
from pathlib import Path
import shutil
import subprocess
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / 'scripts'))
from verify_unity_assets import check_native_leaks

root = Path(__file__).resolve().parents[2]
output = Path(__file__).resolve().parent
workspace = Path('C:/unity-verification/fdb2457a6fef')
project = workspace / 'examples/unity/AssetsDemo'
summary = {}
def method(label, name):
    log = output / (label + '.log')
    cmd = ['unity', 'run', str(project), '--timeout', '800', '--log-file', str(log),
           '--no-tail', '--format', 'json', '--', '-executeMethod', name,
           '-diag-job-temp-memory-leak-validation']
    result = subprocess.run(cmd, cwd=root, capture_output=True, timeout=900)
    (output / (label + '-cli.json')).write_bytes(result.stdout)
    if result.returncode:
        raise RuntimeError(f'{label} failed: {result.returncode}')
    check_native_leaks(log)

for backend in ('Builtin', 'Sbp'):
    label = 'rebuilt-' + backend.lower()
    method(label + '-content', 'AssetsDemoSetup.BuildContent' + backend)
    shutil.copytree(project / 'Assets/StreamingAssets/AiNativeAssets', output / (label + '-content'))
    method(label + '-mono-build', 'AssetsDemoSetup.BuildMono' + ('Standard' if backend == 'Sbp' else ''))
    exe = workspace / 'TestResults/assets-players/Mono/AssetsDemo.exe'
    report = output / (label + '-mono.json')
    log = output / (label + '-mono-player.log')
    subprocess.run([str(exe), '-batchmode', '-force-d3d11', '-assetsSmoke', '-assetsShaderProbe',
                    '-assetsResult', str(report), '-logFile', str(log),
                    '-diag-job-temp-memory-leak-validation'], cwd=exe.parent, check=True, timeout=90,
                   creationflags=subprocess.CREATE_NO_WINDOW)
    check_native_leaks(log)
    result = json.loads(report.read_bytes())
    assert result['success'], result
    assert report.with_suffix('.shader.png').is_file()
    summary[backend] = result
    (output / 'rebuilt-player-summary.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
print(json.dumps(summary))
