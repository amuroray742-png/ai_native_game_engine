from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parents[2]
output = Path(__file__).resolve().parent
workspace = root / 'TestResults/editor-load-mode/workspace'
project = workspace / 'examples/unity/AssetsDemo'
cli = shutil.which('unity')
for relative in ('packages/com.ainative.unitycore.assets/Runtime/AssetPool.cs', 'packages/com.ainative.unitycore.assets/Tests/EditMode/EditorModeOwnershipTests.cs'):
    shutil.copy2(root / relative, workspace / relative)
fingerprints = {}
for base in ('packages/com.ainative.unitycore', 'packages/com.ainative.unitycore.assets', 'examples/unity/AssetsDemo/Assets'):
    for file in (root / base).rglob('*'):
        if file.is_file() and file.suffix in ('.cs', '.asmdef'):
            relative = file.relative_to(root)
            assert file.read_bytes() == (workspace / relative).read_bytes(), relative
            fingerprints[str(relative)] = hashlib.sha256(file.read_bytes()).hexdigest()
(output / 'sources.json').write_text(json.dumps(fingerprints, indent=2), encoding='utf-8')
summary = {}
def run(label, args):
    print(label, flush=True)
    cmd = [cli, *map(str, args)]
    with (output / 'commands.jsonl').open('a', encoding='utf-8') as log:
        log.write(json.dumps(cmd) + '\n')
    result = subprocess.run(cmd, capture_output=True, timeout=900)
    (output / (label + '.stdout.json')).write_bytes(result.stdout)
    (output / (label + '.stderr.txt')).write_bytes(result.stderr)
    result.check_returncode()
def method(label, name):
    run(label, ['run', project, '--timeout', '800', '--log-file', output / (label + '.log'), '--no-tail', '--format', 'json', '--', '-executeMethod', name])
for reload in ('On', 'Off'):
    method('reload-' + reload, 'AssetsDemoSetup.Reload' + reload)
    for mode in ('EditMode', 'PlayMode'):
        label = mode + '-reload-' + reload
        xml = output / (label + '.xml')
        run(label, ['test', project, '--mode', mode, '--filter', 'AiNative.UnityCore', '--output', xml, '--timeout', '800', '--format', 'json', '--', '-logFile', output / (label + '.log')])
        cases = ET.parse(xml).findall('.//test-case')
        assert cases and all(x.get('result') == 'Passed' for x in cases)
        summary[label] = len(cases)
for backend in ('Mono', 'Il2Cpp'):
    method('build-' + backend, 'AssetsDemoSetup.Build' + backend + 'Standard')
    executable = workspace / 'TestResults/assets-players' / backend / 'AssetsDemo.exe'
    result = output / (backend + '-smoke.json')
    subprocess.run([str(executable), '-batchmode', '-assetsSmoke', '-assetsResult', str(result), '-logFile', str(output / (backend + '-player.log'))], check=True, timeout=90, creationflags=subprocess.CREATE_NO_WINDOW)
    summary[backend] = json.loads(result.read_bytes())
    assert summary[backend]['success']
(output / 'summary.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
print(json.dumps(summary), flush=True)
