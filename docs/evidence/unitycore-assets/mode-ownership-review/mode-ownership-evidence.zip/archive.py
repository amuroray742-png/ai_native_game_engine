from pathlib import Path
import hashlib
import json
import shutil
import zipfile

output = Path(__file__).resolve().parent
root = output.parents[1]
destination = root / 'docs/evidence/unitycore-assets/mode-ownership-review'
destination.mkdir(parents=True, exist_ok=True)
summary = json.loads((output / 'summary.json').read_bytes())
summary.update({
    'unity': '6000.3.23f1', 'content_backend': 'SBP 2.6.2',
    'fixed': 'Pool normal close completed before deferred destruction of its root. Now waits until root is actually destroyed.',
    'before_fix': 'before-final.xml: 2 passed; pool close failed because the AssetDatabase pool root remained alive.',
    'test_harness_attempts': 'before.xml failed across domain reload with a captured delegate. before-corrected.log records a Unity test-runner exception during Play entry from setup. Final tests use direct EnterPlayMode in each iterator and create delegates afterwards.',
    'review': 'Independent static audit and final change review passed.',
    'limitations': 'No Inspector mouse interaction or Builtin content rebuild in this review. Existing isolated SBP content reused; both resource loading modes tested. Player validation repeated for runtime cleanup change.',
})
archive = destination / 'mode-ownership-evidence.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as zipped:
    for path in sorted(output.iterdir()):
        if path.is_file() and path.suffix in ('.xml', '.log', '.json', '.jsonl', '.png', '.txt', '.py'):
            zipped.write(path, path.name)
    content = root / 'TestResults/editor-load-mode/workspace/examples/unity/AssetsDemo/Assets/StreamingAssets/AiNativeAssets'
    hashes = {str(p.relative_to(content)): hashlib.sha256(p.read_bytes()).hexdigest() for p in content.rglob('*') if p.is_file() and p.suffix != '.meta'}
    zipped.writestr('content-sha256.json', json.dumps(hashes, indent=2))
    zipped.write(content / 'catalog.json', 'content-catalog.json')
summary['archive_sha256'] = hashlib.sha256(archive.read_bytes()).hexdigest()
(destination / 'summary.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
shutil.copy2(output / 'sources.json', destination / 'sources.json')
print(json.dumps(summary, indent=2))
