using System;
using System.IO;
using System.Linq;
using AiNative.UnityCore.Assets.Editor;
using UnityEditor;
using UnityEditor.Build.Pipeline;
using UnityEditor.Build.Pipeline.Injector;
using UnityEditor.Build.Pipeline.Utilities;
using UnityEditor.Build.Pipeline.Interfaces;
using UnityEngine;

public sealed class SbpProbeCapture : IBuildTask
{
    public int Version => 1;
    [InjectContext(ContextUsage.In)] private IBundleWriteData _write;
    [InjectContext(ContextUsage.In)] private IBundleBuildResults _results;
    public string Output;
    public ReturnCode Run()
    {
        using var writer = new StreamWriter(Path.Combine(Output, "objects.tsv"));
        foreach (var pair in _results.WriteResults)
        {
            foreach (var obj in pair.Value.serializedObjects)
            {
                var id = obj.serializedObject;
                writer.WriteLine(_write.FileToBundle[pair.Key]+"\t"+pair.Key+"\t"+id.guid+"\t"+id.localIdentifierInFile+"\t"+id.fileType+"\t"+id.filePath+"\t"+AssetDatabase.GUIDToAssetPath(id.guid.ToString()));
            }
        }
        return ReturnCode.Success;
    }
}
public static class SbpProbe
{
    public static void InspectLifetime()
    {
        var settings=UnityEngine.Object.Instantiate(AssetDatabase.LoadAssetAtPath<AssetGroups>("Assets/ResourceGroups.asset"));
        settings.hideFlags=HideFlags.None;
        Debug.Log("SETTINGS before native alive="+(settings != null)+" flags="+settings.hideFlags);
        settings.BuildBackend=AssetBuildBackend.Builtin;
        AssetBuilder.Build(settings,Path.GetFullPath("BuildArtifacts/Lifetime/"+Guid.NewGuid().ToString("N")));
        Debug.Log("SETTINGS after native alive="+(settings != null));
    }
    public static void InspectCrc()
    {
        string dir=Directory.GetDirectories("BuildArtifacts/Assets").OrderByDescending(Directory.GetLastWriteTime).First();
        foreach(string p in Directory.GetFiles(dir,"*.bundle"))
        {
            bool ok=BuildPipeline.GetCRCForAssetBundle(p,out uint crc);
            Debug.Log("CRC probe "+p+" ok="+ok+" crc="+crc);
        }
        Debug.Log(File.ReadAllText(Path.Combine(dir,"sbp-write-results.json")).Substring(0,2000));
    }
    public static void Run()
    {
        var plan = AssetBuildPlan.Create(AssetDatabase.LoadAssetAtPath<AssetGroups>("Assets/ResourceGroups.asset"));
        bool previous = ScriptableBuildPipeline.slimWriteResults;
        try
        {
            ScriptableBuildPipeline.slimWriteResults = false;
            for (int i=0;i<2;i++)
            {
                string output=Path.GetFullPath("BuildArtifacts/SbpProbe/"+i);
                Directory.CreateDirectory(output);
                var tasks=DefaultBuildTasks.Create(DefaultBuildTasks.Preset.AssetBundleCompatible);
                tasks.Add(new SbpProbeCapture { Output=output });
                var parameters=new BundleBuildParameters(BuildTarget.StandaloneWindows64,BuildTargetGroup.Standalone,output)
                { BundleCompression=BuildCompression.LZ4, UseCache=true, WriteLinkXML=true, CacheServerHost="", NonRecursiveDependencies=false };
                var code=ContentPipeline.BuildAssetBundles(parameters,new BundleBuildContent(plan.Definitions),out var result,tasks);
                if(code<ReturnCode.Success) throw new Exception(code.ToString());
                File.WriteAllLines(Path.Combine(output,"dependencies.txt"),result.BundleInfos.Select(x=>x.Key+" -> "+string.Join(",",x.Value.Dependencies)));
            }
        }
        finally { ScriptableBuildPipeline.slimWriteResults=previous; }
    }
}
