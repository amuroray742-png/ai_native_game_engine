using System;
using System.IO;
using UnityEditor;
using UnityEngine;
public static class DeploymentMenuProbe
{
    public static void Run()
    {
        Selection.activeObject = AssetDatabase.LoadMainAssetAtPath("Assets/ResourceGroups.asset");
        if (!EditorApplication.ExecuteMenuItem("AI Native/Assets/Copy latest build to StreamingAssets"))
        { throw new Exception("Deployment menu was not invoked."); }
        string root = Path.Combine(Application.streamingAssetsPath, "AiNativeAssets");
        var catalog = JsonUtility.FromJson<AiNative.UnityCore.Assets.AssetCatalog>(File.ReadAllText(Path.Combine(root, "catalog.json")));
        catalog.Validate();
        foreach (string file in Directory.GetFiles(root))
        {
            if (file.EndsWith(".meta")) { continue; }
            if (Path.GetFileName(file) != "catalog.json" && !Array.Exists(catalog.Bundles, b => b.Name == Path.GetFileName(file)))
            { throw new Exception("Unexpected deployment file: " + file); }
        }
        Debug.Log("PASS: actual menu invocation deployed runtime-only content.");
    }
}
