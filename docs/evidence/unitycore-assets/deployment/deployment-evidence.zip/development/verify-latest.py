from pathlib import Path
import json,shutil,subprocess
out=Path('TestResults/assets-deployment').resolve();project=out/'workspace/examples/unity/AssetsDemo';cli=shutil.which('unity')
for label,method,extra in [
 ('batch-build-record','AiNative.UnityCore.Assets.Editor.AssetBuilder.BatchBuild',['-assetGroups','Assets/ResourceGroups.asset','-assetOutput',str(out/'batch-built')]),
 ('batch-copy-latest','AiNative.UnityCore.Assets.Editor.AssetDeployment.BatchCopy',['-assetGroups','Assets/ResourceGroups.asset'])]:
 command=[cli,'run',str(project),'--timeout','800','--log-file',str(out/(label+'.log')),'--no-tail','--format','json','--','-executeMethod',method,*extra]
 with (out/'extra-commands.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(command)+'\n')
 r=subprocess.run(command,capture_output=True,timeout=900)
 (out/(label+'.stdout.json')).write_bytes(r.stdout);(out/(label+'.stderr.txt')).write_bytes(r.stderr)
 if r.returncode: raise RuntimeError(label)
 print(label+' passed',flush=True)
