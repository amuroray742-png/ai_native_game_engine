from pathlib import Path
import json,shutil,subprocess
out=Path('TestResults/assets-deployment').resolve();project=out/'workspace/examples/unity/AssetsDemo';cli=shutil.which('unity')
source=next(p.parent for p in (project/'BuildArtifacts/DeploymentTests').glob('*/source/build-metadata.json') if json.loads(p.read_bytes())['Backend']==1)
command=[cli,'run',str(project),'--timeout','800','--log-file',str(out/'batch-explicit-native.log'),'--no-tail','--format','json','--','-executeMethod','AiNative.UnityCore.Assets.Editor.AssetDeployment.BatchCopy','-assetSource',str(source)]
(out/'extra-commands.jsonl').write_text(json.dumps(command)+'\n',encoding='utf-8')
r=subprocess.run(command,capture_output=True,timeout=900)
(out/'batch-explicit-native.stdout.json').write_bytes(r.stdout);(out/'batch-explicit-native.stderr.txt').write_bytes(r.stderr)
print(r.returncode,flush=True)
if r.returncode: raise RuntimeError('native deploy failed')
command=[cli,'run',str(project),'--timeout','800','--log-file',str(out/'builtin-standard-rejected.log'),'--no-tail','--format','json','--','-executeMethod','AssetsDemoSetup.BuildMonoStandard']
with (out/'extra-commands.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(command)+'\n')
r=subprocess.run(command,capture_output=True,timeout=900)
(out/'builtin-standard-rejected.stdout.json').write_bytes(r.stdout);(out/'builtin-standard-rejected.stderr.txt').write_bytes(r.stderr)
assert r.returncode!=0
assert 'Builtin content requires AssetPlayerBuildSupport.BuildDeployedPlayer' in (out/'builtin-standard-rejected.log').read_text(encoding='utf-8-sig')
print('Builtin standard Player build rejected as required.',flush=True)
