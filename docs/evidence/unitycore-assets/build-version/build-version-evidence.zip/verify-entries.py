from pathlib import Path
import json,re,shutil,subprocess,xml.etree.ElementTree as ET
root=Path(__file__).resolve().parent
project=root/'workspace/examples/unity/AssetsDemo'
cli=shutil.which('unity')
def run(label,args):
    command=[cli,*map(str,args)]
    with (root/'commands.jsonl').open('a',encoding='utf-8') as f: f.write(json.dumps(command)+'\n')
    print(label,flush=True)
    result=subprocess.run(command,capture_output=True,timeout=900)
    (root/(label+'.stdout.json')).write_bytes(result.stdout)
    (root/(label+'.stderr.txt')).write_bytes(result.stderr)
    if result.returncode: raise RuntimeError(f'{label}: exit {result.returncode}')
def method(label,name,extra=()):
    run(label,['run',project,'--timeout','800','--log-file',root/(label+'.log'),'--no-tail','--format','json','--','-executeMethod',name,*extra])
summary={}
for label,extra,output,version in [
    ('batch-default',[],project/'BundleBuildOutput/1',1),
    ('batch-override',['-assetOutput',root/'override-output','-assetCleanBuild'],root/'override-output',2)]:
    method(label,'AiNative.UnityCore.Assets.Editor.AssetBuilder.BatchBuild',['-assetGroups','Assets/ResourceGroups.asset',*extra])
    metadata=json.loads((output/'build-metadata.json').read_bytes())
    assert metadata['ContentVersion']==version,metadata
    assert metadata['UseCache']==(version==1)
    assert re.search(r'^  Version: '+str(version+1)+r'$',(project/'Assets/ResourceGroups.asset').read_text(encoding='utf-8'),re.M)
    summary[label]={'contentVersion':version,'nextVersion':version+1,'output':str(output)}
content=project/'Assets/StreamingAssets/AiNativeAssets'
if content.exists(): content.rename(root/'copied-content')
method('demo-content','AssetsDemoSetup.BuildContent')
assert json.loads((content/'build-metadata.json').read_bytes())['ContentVersion']==3
assert re.search(r'^  Version: 3$',(project/'Assets/ResourceGroups.asset').read_text(encoding='utf-8'),re.M)
run('EditMode',['test',project,'--mode','EditMode','--filter','AiNative.UnityCore','--output',root/'EditMode.xml','--timeout','800','--format','json','--','-logFile',root/'EditMode.log'])
run('PlayMode',['test',project,'--mode','PlayMode','--filter','AiNative.UnityCore','--output',root/'PlayMode.xml','--timeout','800','--format','json','--','-logFile',root/'PlayMode.log'])
for mode in ['EditMode','PlayMode']:
    cases=ET.parse(root/(mode+'.xml')).findall('.//test-case')
    assert cases and all(c.get('result')=='Passed' for c in cases)
    summary[mode]=len(cases)
(root/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps(summary),flush=True)
