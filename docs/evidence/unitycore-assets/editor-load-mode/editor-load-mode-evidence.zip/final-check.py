import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parents[2]
output = Path(__file__).resolve().parent
workspace = output / 'workspace'
project = workspace / 'examples/unity/AssetsDemo'
for relative in (
    'packages/com.ainative.unitycore.assets/Tests/EditMode/AssetPlayCycleTests.cs',
    'packages/com.ainative.unitycore.assets/Editor/AssetGroupsInspector.cs',
):
    shutil.copy2(root / relative, workspace / relative)
hashes = {}
for base in ('packages/com.ainative.unitycore', 'packages/com.ainative.unitycore.assets', 'examples/unity/AssetsDemo/Assets'):
    for source in (root / base).rglob('*'):
        if source.is_file() and source.suffix in ('.cs', '.asmdef'):
            relative = source.relative_to(root)
            assert source.read_bytes() == (workspace / relative).read_bytes(), relative
            hashes[str(relative)] = hashlib.sha256(source.read_bytes()).hexdigest()
(output / 'final-sources.json').write_text(json.dumps(hashes, indent=2), encoding='utf-8')
cli = shutil.which('unity')
for reload in ('Off', 'On'):
    if reload == 'On':
        subprocess.run([cli, 'run', str(project), '--timeout', '800', '--log-file', str(output / 'final-reload-On.log'), '--no-tail', '--format', 'json', '--', '-executeMethod', 'AssetsDemoSetup.ReloadOn'], check=True)
    label = 'final-mode-tests-reload-' + reload
    command = [cli, 'test', str(project), '--mode', 'EditMode', '--filter', 'AiNative.UnityCore.Assets.Tests.AssetPlayCycleTests', '--output', str(output / (label + '.xml')), '--timeout', '800', '--format', 'json', '--', '-logFile', str(output / (label + '.log'))]
    with (output / 'commands.jsonl').open('a', encoding='utf-8') as log:
        log.write(json.dumps(command) + '\n')
    result = subprocess.run(command, capture_output=True)
    (output / (label + '.stdout.json')).write_bytes(result.stdout)
    (output / (label + '.stderr.txt')).write_bytes(result.stderr)
    result.check_returncode()
    cases = ET.parse(output / (label + '.xml')).findall('.//test-case')
    assert len(cases) == 5 and all(x.get('result') == 'Passed' for x in cases)
    print(label, len(cases), flush=True)
