import hashlib
import json
from pathlib import Path
import shutil
import zipfile

output = Path(__file__).resolve().parent
root = output.parents[1]
destination = root / 'docs/evidence/unitycore-assets/editor-load-mode'
destination.mkdir(parents=True, exist_ok=True)
archive = destination / 'editor-load-mode-evidence.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as zipped:
    for path in sorted(output.iterdir()):
        if path.is_file() and path.suffix in ('.log', '.xml', '.json', '.jsonl', '.png', '.txt', '.py', '.asset'):
            zipped.write(path, path.name)
    for name in ('verify_unity_assets.py', 'unity_packages.py'):
        zipped.write(root / 'scripts' / name, 'reproduce/' + name)
summary = json.loads((output / 'summary.json').read_bytes())
summary.update({
    'unity': '6000.3.23f1', 'sbp': '2.6.2',
    'final_targeted_mode_tests': {'DomainReloadOff': 5, 'DomainReloadOn': 5},
    'independent_review': 'Passed; explicit missing bundle directory negative case added and verified.',
    'scope': 'Full SBP regression and Players used initial implementation; final test and Inspector help additions followed by focused mode regressions. Runtime/factory/example code unchanged between runs.',
    'not_executed': ['Inspector mouse interaction', 'Builtin backend rerun (no backend code changed)'],
    'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
})
(destination / 'summary.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
shutil.copy2(output / 'final-sources.json', destination / 'sources.json')
print(json.dumps(summary, indent=2))
